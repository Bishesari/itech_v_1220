<?php

return [
    'base_url' => 'https://sms.parsgreen.ir',
    'api_key' => env('PARSGREEN_API_KEY'),
];
